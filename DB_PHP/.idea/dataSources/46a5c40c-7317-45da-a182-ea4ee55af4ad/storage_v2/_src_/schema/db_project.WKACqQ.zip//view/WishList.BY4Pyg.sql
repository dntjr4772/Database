create view WishList as
select `db_project`.`company`.`name`            AS `name`,
       `db_project`.`rentcar`.`model`           AS `model`,
       `db_project`.`rentcar`.`location`        AS `location`,
       `db_project`.`rentcar`.`car_num`         AS `car_num`,
       `db_project`.`rentcar`.`type`            AS `type`,
       `db_project`.`rentcar`.`distance_driven` AS `distance_driven`
from (`db_project`.`rentcar`
         join `db_project`.`company`)
where (`db_project`.`rentcar`.`model` = 'K5');

